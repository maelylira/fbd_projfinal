from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import List
from datetime import datetime
from sqlalchemy.orm import Session
from database import Curtida, get_db

router = APIRouter()

class CurtidaCreateSchema(BaseModel):
    id_usuario1: int
    id_usuario2: int
    data_curtida: datetime
    class Config:
        from_attributes = True

class CurtidaSchema(CurtidaCreateSchema):
    pass

@router.get("/", response_model=List[CurtidaSchema])
def listar_curtidas(db: Session = Depends(get_db)):
    return db.query(Curtida).all()

@router.post("/", response_model=CurtidaSchema)
def criar_curtida(curtida: CurtidaCreateSchema, db: Session = Depends(get_db)):
    nova_curtida = Curtida(**curtida.dict())
    db.add(nova_curtida)
    db.commit()
    return nova_curtida

@router.delete("/{id_usuario}/{id_resenha}")
def deletar_curtida(id_usuario: int, id_resenha: int, db: Session = Depends(get_db)):
    curtida = db.query(Curtida).filter(
        Curtida.id_usuario == id_usuario,
        Curtida.id_resenha == id_resenha
    ).first()
    if not curtida:
        raise HTTPException(status_code=404, detail="Curtida não encontrada")
    db.delete(curtida)
    db.commit()
    return {"message": "Curtida removida com sucesso"}
