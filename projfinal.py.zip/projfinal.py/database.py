from sqlalchemy import create_engine, Column, Integer, String, Date, Text, ForeignKey, TIMESTAMP
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.orm import Session
from fastapi import Depends

DATABASE_URL = "postgresql://postgres:admin123@localhost:5432/projeto"

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# ------------------- MODELOS -------------------
class Usuario(Base):
    __tablename__ = "usuario"
    id_usuario = Column(Integer, primary_key=True, index=True, autoincrement=True)
    nome = Column(String(100))
    email = Column(String(100))
    senha = Column(String(100))
    data_nascimento = Column(Date)
    bio = Column(Text)

class Livro(Base):
    __tablename__ = "livro"
    id_livro = Column(Integer, primary_key=True, index=True, autoincrement=True)
    titulo = Column(String(100))
    autor = Column(String(100))
    editora = Column(String(100))
    ano_publicacao = Column(Integer)
    genero = Column(String(100))
    descricao = Column(Text)
    imagem_capa = Column(String(100))

class Resenha(Base):
    __tablename__ = "resenha"
    id_resenha = Column(Integer, primary_key=True, index=True, autoincrement=True)
    id_usuario = Column(Integer, ForeignKey("usuario.id_usuario"))
    conteudo = Column(Text)
    data_resenha = Column(Date)

class Comentario(Base):
    __tablename__ = "comentario"
    id_comentario = Column(Integer, primary_key=True, index=True, autoincrement=True)
    id_usuario = Column(Integer, ForeignKey("usuario.id_usuario"))
    id_resenha = Column(Integer, ForeignKey("resenha.id_resenha"))
    conteudo = Column(Text)
    data_comentario = Column(TIMESTAMP)


class Curtida(Base):
    __tablename__ = "curtida"
    id_usuario = Column(Integer, ForeignKey("usuario.id_usuario"), primary_key=True)
    id_resenha = Column(Integer, ForeignKey("resenha.id_resenha"), primary_key=True)
    data_curtida = Column(TIMESTAMP)

class Estante(Base):
    __tablename__ = "estante"
    id_estante = Column(Integer, primary_key=True, index=True, autoincrement=True)
    id_usuario = Column(Integer, ForeignKey("usuario.id_usuario"))
    id_livro = Column(Integer, ForeignKey("livro.id_livro"))
    status_leitura = Column(String(30))

class Seguidores(Base):
    __tablename__ = "seguidores"
    id_usuario1 = Column(Integer, ForeignKey("usuario.id_usuario"), primary_key=True, autoincrement=True)
    id_usuario2 = Column(Integer, ForeignKey("usuario.id_usuario"), primary_key=True, autoincrement=True)
    data_inicio = Column(TIMESTAMP)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()