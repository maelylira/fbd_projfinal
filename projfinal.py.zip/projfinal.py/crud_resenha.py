from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import List
from datetime import date
from sqlalchemy.orm import Session
from database import Resenha, Comentario, Curtida, get_db

router = APIRouter()

# Schema para criar resenha
class ResenhaCreateSchema(BaseModel):
    id_resenha: int
    id_usuario: int
    conteudo: str
    data_resenha: date

# Schema de retorno
class ResenhaSchema(ResenhaCreateSchema):
    id_resenha: int

    class Config:
        from_attributes = True


# GET - Listar resenhas
@router.get("/", response_model=List[ResenhaSchema])
def listar_resenhas(db: Session = Depends(get_db)):
    resenhas = db.query(Resenha).all()
    print(f"[DEBUG] Listando {len(resenhas)} resenhas do banco.")
    for r in resenhas:
        print(f"[DEBUG] Resenha ID {r.id_resenha} - Usuário {r.id_usuario}")
    return resenhas


# POST - Criar resenha
@router.post("/", response_model=ResenhaSchema)
def criar_resenha(resenha: ResenhaCreateSchema, db: Session = Depends(get_db)):
    nova_resenha = Resenha(**resenha.dict())
    db.add(nova_resenha)
    db.commit()
    db.refresh(nova_resenha)
    print(f"[DEBUG] Resenha criada com ID {nova_resenha.id_resenha}")
    return nova_resenha


# DELETE - Deletar resenha
@router.delete("/{id_resenha}")
def deletar_resenha(id_resenha: int, db: Session = Depends(get_db)):
    resenha = db.query(Resenha).filter(Resenha.id_resenha == id_resenha).first()

    if not resenha:
        print(f"[DEBUG] Resenha com ID {id_resenha} não encontrada para exclusão.")
        raise HTTPException(status_code=404, detail="Resenha não encontrada")

    # Apaga filhos
    deleted_comments = db.query(Comentario).filter(Comentario.id_resenha == id_resenha).delete()
    deleted_likes = db.query(Curtida).filter(Curtida.id_resenha == id_resenha).delete()
    print(f"[DEBUG] {deleted_comments} comentários e {deleted_likes} curtidas removidos antes da resenha.")

    db.delete(resenha)
    db.commit()
    print(f"[DEBUG] Resenha ID {id_resenha} deletada com sucesso.")
    return {"message": "Resenha e registros relacionados foram removidos com sucesso"}