from database import Base, engine

print("Criando todas as tabelas...")
Base.metadata.create_all(bind=engine)
print("Tabelas criadas com sucesso!")
