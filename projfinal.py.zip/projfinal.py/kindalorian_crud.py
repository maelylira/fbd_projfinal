from flask import Flask, request, jsonify
import psycopg2
from psycopg2.extras import RealDictCursor
from db import get_connection

app = Flask(__name__)


def execute_query(query, values=None, fetch=False):
    try:
        conn = get_connection()
        cursor = conn.cursor(cursor_factory=RealDictCursor)
        cursor.execute(query, values)
        result = None
        if fetch:
            result = cursor.fetchall()
        conn.commit()
        return result
    except Exception as e:
        print(f"Database error: {e}")
        return None
    finally:
        if 'cursor' in locals():
            cursor.close()
        if 'conn' in locals():
            conn.close()
            
# ----------------- CRUD USUÁRIO -----------------

@app.route('/usuarios', methods=['GET'])
def get_usuarios():
    return jsonify(execute_query("SELECT * FROM usuario", fetch=True))


@app.route('/usuarios', methods=['POST'])
def create_usuario():
    data = request.json
    query = """
        INSERT INTO usuario (nome, email, senha)
        VALUES (%s, %s, %s)
    """
    execute_query(query, (data['nome'], data['email'], data['senha']))
    return jsonify({"mensagem": "Usuário criado com sucesso"})

@app.route('/usuarios/<int:id>', methods=['PUT'])
def update_usuario(id):
    data = request.json
    query = """
        UPDATE usuario SET nome=%s, email=%s, senha=%s WHERE id=%s
    """
    execute_query(query, (data['nome'], data['email'], data['senha'], id))
    return jsonify({"mensagem": "Usuário atualizado com sucesso"})

@app.route('/usuarios/<int:id>', methods=['DELETE'])
def delete_usuario(id):
    query = "DELETE FROM usuario WHERE id=%s"
    execute_query(query, (id,))
    return jsonify({"mensagem": "Usuário deletado com sucesso"})

# ----------------- CRUD LIVRO -----------------

@app.route('/livros', methods=['GET'])
def get_livros():
    return jsonify(execute_query("SELECT  FROM livro", fetch=True))

@app.route('/livros', methods=['POST'])
def create_livro():
    data = request.json
    query = """
        INSERT INTO livro (titulo, autor, ano, genero)
        VALUES (%s, %s, %s, %s)
    """
    execute_query(query, (data['titulo'], data['autor'], data['ano'], data['genero']))
    return jsonify({"mensagem": "Livro criado com sucesso"})

@app.route('/livros/<int:id>', methods=['PUT'])
def update_livro(id):
    data = request.json
    query = """
        UPDATE livro SET titulo=%s, autor=%s, ano=%s, genero=%s WHERE id=%s
    """
    execute_query(query, (data['titulo'], data['autor'], data['ano'], data['genero'], id))
    return jsonify({"mensagem": "Livro atualizado com sucesso"})

@app.route('/livros/<int:id>', methods=['DELETE'])
def delete_livro(id):
    execute_query("DELETE FROM livro WHERE id=%s", (id,))
    return jsonify({"mensagem": "Livro deletado com sucesso"})

# ----------------- CRUD RESENHA -----------------

@app.route('/resenhas', methods=['GET'])
def get_resenhas():
    return jsonify(execute_query("SELECT * FROM resenha", fetch=True))

@app.route('/resenhas', methods=['POST'])
def create_resenha():
    data = request.json
    query = """
        INSERT INTO resenha (id_usuario, id_livro, texto)
        VALUES (%s, %s, %s)
    """
    execute_query(query, (data['id_usuario'], data['id_livro'], data['texto']))
    return jsonify({"mensagem": "Resenha criada com sucesso"})

@app.route('/resenhas/<int:id>', methods=['PUT'])
def update_resenha(id):
    data = request.json
    query = """
        UPDATE resenha SET id_usuario=%s, id_livro=%s, texto=%s WHERE id=%s
    """
    execute_query(query, (data['id_usuario'], data['id_livro'], data['texto'], id))
    return jsonify({"mensagem": "Resenha atualizada com sucesso"})

@app.route('/resenhas/<int:id>', methods=['DELETE'])
def delete_resenha(id):
    execute_query("DELETE FROM resenha WHERE id=%s", (id,))
    return jsonify({"mensagem": "Resenha deletada com sucesso"})

# ----------------- CRUD COMENTÁRIO -----------------

@app.route('/comentarios', methods=['GET'])
def get_comentarios():
    return jsonify(execute_query("SELECT * FROM comentario", fetch=True))

@app.route('/comentarios', methods=['POST'])
def create_comentario():
    data = request.json
    query = """
        INSERT INTO comentario (id_usuario, id_resenha, texto)
        VALUES (%s, %s, %s)
    """
    execute_query(query, (data['id_usuario'], data['id_resenha'], data['texto']))
    return jsonify({"mensagem": "Comentário criado com sucesso"})

@app.route('/comentarios/<int:id>', methods=['PUT'])
def update_comentario(id):
    data = request.json
    query = """
        UPDATE comentario SET id_usuario=%s, id_resenha=%s, texto=%s WHERE id=%s
    """
    execute_query(query, (data['id_usuario'], data['id_resenha'], data['texto'], id))
    return jsonify({"mensagem": "Comentário atualizado com sucesso"})

@app.route('/comentarios/<int:id>', methods=['DELETE'])
def delete_comentario(id):
    execute_query("DELETE FROM comentario WHERE id=%s", (id,))
    return jsonify({"mensagem": "Comentário deletado com sucesso"})

# ----------------- CRUD AVALIAÇÃO -----------------

@app.route('/avaliacoes', methods=['GET'])
def get_avaliacoes():
    return jsonify(execute_query("SELECT * FROM avaliacao", fetch=True))

@app.route('/avaliacoes', methods=['POST'])
def create_avaliacao():
    data = request.json
    query = """
        INSERT INTO avaliacao (id_usuario, id_livro, nota)
        VALUES (%s, %s, %s)
    """
    execute_query(query, (data['id_usuario'], data['id_livro'], data['nota']))
    return jsonify({"mensagem": "Avaliação criada com sucesso"})

@app.route('/avaliacoes/<int:id>', methods=['PUT'])
def update_avaliacao(id):
    data = request.json
    query = """
        UPDATE avaliacao SET id_usuario=%s, id_livro=%s, nota=%s WHERE id=%s
    """
    execute_query(query, (data['id_usuario'], data['id_livro'], data['nota'], id))
    return jsonify({"mensagem": "Avaliação atualizada com sucesso"})

@app.route('/avaliacoes/<int:id>', methods=['DELETE'])
def delete_avaliacao(id):
    execute_query("DELETE FROM avaliacao WHERE id=%s", (id,))
    return jsonify({"mensagem": "Avaliação deletada com sucesso"})

# ----------------- CRUD CURTIDA -----------------

@app.route('/curtidas', methods=['GET'])
def get_curtidas():
    return jsonify(execute_query("SELECT * FROM curtida", fetch=True))

@app.route('/curtidas', methods=['POST'])
def create_curtida():
    data = request.json
    query = """
        INSERT INTO curtida (id_usuario, id_resenha)
        VALUES (%s, %s)
    """
    execute_query(query, (data['id_usuario'], data['id_resenha']))
    return jsonify({"mensagem": "Curtida criada com sucesso"})

@app.route('/curtidas/<int:id>', methods=['DELETE'])
def delete_curtida(id):
    execute_query("DELETE FROM curtida WHERE id=%s", (id,))
    return jsonify({"mensagem": "Curtida removida com sucesso"})

# ----------------- CRUD ESTANTE -----------------

@app.route('/estantes', methods=['GET'])
def get_estantes():
    return jsonify(execute_query("SELECT * FROM estante", fetch=True))

@app.route('/estantes', methods=['POST'])
def create_estante():
    data = request.json
    query = """
        INSERT INTO estante (id_usuario, id_livro, status)
        VALUES (%s, %s, %s)
    """
    execute_query(query, (data['id_usuario'], data['id_livro'], data['status']))
    return jsonify({"mensagem": "Livro adicionado à estante"})

@app.route('/estantes/<int:id>', methods=['DELETE'])
def delete_estante(id):
    execute_query("DELETE FROM estante WHERE id=%s", (id,))
    return jsonify({"mensagem": "Livro removido da estante"})

# ----------------- CRUD SEGUIDORES -----------------

@app.route('/seguidores', methods=['GET'])
def get_seguidores():
    return jsonify(execute_query("SELECT * FROM seguidores", fetch=True))

@app.route('/seguidores', methods=['POST'])
def create_seguidor():
    data = request.json
    query = """
        INSERT INTO seguidores (id_usuario, id_seguido)
        VALUES (%s, %s)
    """
    execute_query(query, (data['id_usuario'], data['id_seguido']))
    return jsonify({"mensagem": "Agora você está seguindo esse usuário"})

@app.route('/seguidores/<int:id>', methods=['DELETE'])
def delete_seguidor(id):
    execute_query("DELETE FROM seguidores WHERE id=%s", (id,))
    return jsonify({"mensagem": "Deixou de seguir o usuário"})

#---------------------------=------------------------#
if __name__ == '__main__':
    app.run(debug=True)