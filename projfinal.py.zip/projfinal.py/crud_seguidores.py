from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import List
from datetime import datetime
from sqlalchemy.orm import Session
from database import Seguidores, get_db

router = APIRouter()

class SeguidoresCreateSchema(BaseModel):
    id_usuario1: int
    id_usuario2: int
    data_inicio: datetime
    class Config:
        from_attributes = True

class SeguidoresSchema(SeguidoresCreateSchema):
    pass

@router.get("/", response_model=List[SeguidoresSchema])
def listar_seguidores(db: Session = Depends(get_db)):
    return db.query(Seguidores).all()

@router.post("/", response_model=SeguidoresSchema)
def criar_seguidor(seguidor: SeguidoresCreateSchema, db: Session = Depends(get_db)):
    novo = Seguidores(**seguidor.dict())
    db.add(novo)
    db.commit()
    return novo

@router.delete("/{id_usuario1}/{id_usuario2}")
def deletar_seguidor(id_usuario1: int, id_usuario2: int, db: Session = Depends(get_db)):
    seguidor = db.query(Seguidores).filter(
        Seguidores.id_usuario1 == id_usuario1,
        Seguidores.id_usuario2 == id_usuario2
    ).first()
    if not seguidor:
        raise HTTPException(status_code=404, detail="Seguidor não encontrado")
    db.delete(seguidor)
    db.commit()
    return {"message": "Seguidor removido com sucesso"}
