from fastapi import FastAPI

# Importando os routers
from crud_usuario import router as usuario_router
from crud_livro import router as livro_router
from crud_resenha import router as resenha_router
from crud_curtida import router as curtida_router
from crud_estante import router as estante_router
from crud_seguidores import router as seguidores_router
from crud_comentario import router as comentario_router

# Criação do app FastAPI
app = FastAPI(
    title="API do Projeto de Livros",
    version="1.0.0",
    description="API para gerenciar usuários, livros, resenhas, curtidas, estantes e seguidores."
)

# Incluindo os routers
app.include_router(usuario_router, prefix="/usuarios", tags=["USUARIOS"])
app.include_router(comentario_router, prefix="/comentarios", tags=["COMENTARIOS"])
app.include_router(livro_router, prefix="/livros", tags=["LIVROS"])
app.include_router(resenha_router, prefix="/resenhas", tags=["RESENHAS"])
app.include_router(curtida_router, prefix="/curtidas", tags=["CURTIDAS"])
app.include_router(estante_router, prefix="/estantes", tags=["ESTANTES"])
app.include_router(seguidores_router, prefix="/seguidores", tags=["SEGUIDORES"])

# Rota raiz
@app.get("/")
def raiz():
    return {"message": "Bem-vindo à API do Projeto de Livros!"}
