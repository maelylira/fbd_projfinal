import psycopg2

def get_connection():
    return psycopg2.connect(
        dbname="projeto",
        user="postgres",
        password="admin123",
        host="localhost",
        port="5432"
    )