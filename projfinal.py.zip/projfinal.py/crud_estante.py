from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import List
from sqlalchemy.orm import Session
from database import Estante, get_db

router = APIRouter()

class EstanteCreateSchema(BaseModel):
    id_usuario: int
    id_livro: int
    status_leitura: str
    class Config:
        from_attributes = True

class EstanteSchema(EstanteCreateSchema):
    id_estante: int

@router.get("/", response_model=List[EstanteSchema])
def listar_estantes(db: Session = Depends(get_db)):
    return db.query(Estante).all()

@router.post("/", response_model=EstanteSchema)
def criar_estante(estante: EstanteCreateSchema, db: Session = Depends(get_db)):
    nova_estante = Estante(**estante.dict())
    db.add(nova_estante)
    db.commit()
    db.refresh(nova_estante)
    return nova_estante

@router.delete("/{id_estante}")
def deletar_estante(id_estante: int, db: Session = Depends(get_db)):
    estante = db.query(Estante).filter(Estante.id_estante == id_estante).first()
    if not estante:
        raise HTTPException(status_code=404, detail="Estante não encontrada")
    db.delete(estante)
    db.commit()
    return {"message": "Estante removida com sucesso"}
