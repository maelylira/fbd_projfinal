from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import List
from datetime import datetime
from sqlalchemy.orm import Session
from database import Comentario, get_db

router = APIRouter()

# Schema para criação
class ComentarioCreateSchema(BaseModel):
    id_usuario: int
    id_comentario: int
    conteudo: str
    data_comentario: datetime

# Schema de retorno
class ComentarioSchema(ComentarioCreateSchema):
    id_comentario: int

    class Config:
        from_attributes = True

# GET - Listar comentários
@router.get("/", response_model=List[ComentarioSchema])
def listar_comentarios(db: Session = Depends(get_db)):
    return db.query(Comentario).all()

# POST - Criar comentário
@router.post("/", response_model=ComentarioSchema)
def criar_comentario(comentario: ComentarioCreateSchema, db: Session = Depends(get_db)):
    novo_comentario = Comentario(**comentario.dict())
    db.add(novo_comentario)
    db.commit()
    db.refresh(novo_comentario)
    return novo_comentario

# DELETE - Remover comentário
@router.delete("/{id_comentario}")
def deletar_comentario(id_comentario: int, db: Session = Depends(get_db)):
    comentario = db.query(Comentario).filter(Comentario.id_comentario == id_comentario).first()
    if not comentario:
        raise HTTPException(status_code=404, detail="Comentário não encontrado")

    db.delete(comentario)
    db.commit()
    return {"message": "Comentário removido com sucesso"}