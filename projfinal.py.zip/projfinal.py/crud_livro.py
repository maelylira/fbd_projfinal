from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import List
from sqlalchemy.orm import Session
from database import Livro, Estante, get_db

router = APIRouter()

class LivroCreateSchema(BaseModel):
    id_livro: int
    titulo: str
    autor: str
    editora: str
    ano_publicacao: int
    genero: str
    descricao: str
    class Config:
        from_attributes = True

class LivroSchema(LivroCreateSchema):
    id_livro: int

@router.get("/", response_model=List[LivroSchema])
def listar_livros(db: Session = Depends(get_db)):
    return db.query(Livro).all()

@router.post("/", response_model=LivroSchema)
def criar_livro(livro: LivroCreateSchema, db: Session = Depends(get_db)):
    novo_livro = Livro(**livro.dict())
    db.add(novo_livro)
    db.commit()
    db.refresh(novo_livro)
    return novo_livro

@router.delete("/{id_livro}")
def deletar_livro(id_livro: int, db: Session = Depends(get_db)):
    db.query(Estante).filter(Estante.id_livro == id_livro).delete()
    livro = db.query(Livro).filter(Livro.id_livro == id_livro).first()
    if not livro:
        raise HTTPException(status_code=404, detail="Livro não encontrado")
    db.delete(livro)
    db.commit()
    return {"message": "Livro removido com sucesso"}
