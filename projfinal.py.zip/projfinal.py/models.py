from pydantic import BaseModel
from typing import List, Optional
from datetime import date, datetime

class Usuario(BaseModel):
    id_usuario: int
    nome: str
    email: str
    senha: str
    data_nascimento: date

class UsuarioCreate(BaseModel):
    id_usuario: int
    nome: str
    email: str
    senha: str
    data_nascimento: date

class UsuarioUpdate(BaseModel):
    id_usuario:Optional [int] = None
    nome: Optional [str] = None
    email: Optional [str] = None
    senha: Optional [str] = None
    data_nascimento: Optional [date] = None

class Livro(BaseModel):
    id_livro: int
    titulo: str
    autor: str
    editora: str
    editora: str
    ano_publicacao: int
    genero: str
    descricao: str

class LivroCreate(BaseModel):
    id_livro: int
    titulo: str
    autor: str
    editora: str
    editora: str
    ano_publicacao: int
    genero: str
    descricao: str

class LivroUpdate(BaseModel):
    titulo: Optional [str] = None
    autor: Optional [str] = None
    editora: Optional [str] = None
    editora: Optional [str] = None
    ano_publicacao: Optional [int] = None
    genero: Optional [str] = None
    descricao: Optional [str] = None
    
class Resenha(BaseModel):
    id_livro: int
    id_usuario: int
    conteudo: str
    data_comentario:Optional[date] = None

class ResenhaCreate(BaseModel):
    id_livro: int
    id_usuario: int
    conteudo: str
    data_comentario: Optional[date] = None

class ResenhaUpadte(BaseModel):
    id_livro: Optional [int] = None
    id_usuario: Optional [int] = None
    conteudo: Optional [str] = None
    data_comentario: Optional[date] = None
    
class Curtida(BaseModel):
    id_usuario: int
    id_resenha: int
    data_curtida: datetime

class CurtidaCreate(BaseModel):
    id_usuario: int
    id_resenha: int
    data_curtida: datetime
    
class Estante(BaseModel):
    id_estante: int
    id_usuario: int
    id_livro: int
    status_leitura: str

class EstanteCreate(BaseModel):
    id_estante: int
    id_usuario: int
    id_livro: int
    status_leitura: str
    
class Seguidor(BaseModel):
    id_usuario1: int
    id_usuario2: int
    data_inicio: datetime
    
class SeguidorCreate(BaseModel):
    id_usuario1: int
    id_usuario2: int
    data_inicio: datetime
