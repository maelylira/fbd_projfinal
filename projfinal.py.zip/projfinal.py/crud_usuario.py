from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import List, Optional
from datetime import date
from sqlalchemy.orm import Session
from database import Usuario, Resenha, Curtida, Estante, Seguidores, get_db

router = APIRouter()

class UsuarioCreateSchema(BaseModel):
    id_usuario: int
    nome: str
    email: str
    senha: str
    data_nascimento: date
    bio: Optional[str] = None

class UsuarioSchema(UsuarioCreateSchema):
    id_usuario: int
    class Config:
        from_attributes = True

@router.get("/", response_model=List[UsuarioSchema])
def listar_usuarios(db: Session = Depends(get_db)):
    return db.query(Usuario).all()

@router.post("/", response_model=UsuarioSchema)
def criar_usuario(usuario: UsuarioCreateSchema, db: Session = Depends(get_db)):
    novo_usuario = Usuario(**usuario.dict())
    db.add(novo_usuario)
    db.commit()
    db.refresh(novo_usuario)
    return novo_usuario

@router.delete("/{id_usuario}")
def deletar_usuario(id_usuario: int, db: Session = Depends(get_db)):
    db.query(Curtida).filter(Curtida.id_usuario == id_usuario).delete()
    db.query(Estante).filter(Estante.id_usuario == id_usuario).delete()
    db.query(Resenha).filter(Resenha.id_usuario == id_usuario).delete()
    db.query(Seguidores).filter(
        (Seguidores.id_usuario1 == id_usuario) | (Seguidores.id_usuario2 == id_usuario)
    ).delete()

    usuario = db.query(Usuario).filter(Usuario.id_usuario == id_usuario).first()
    if not usuario:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")
    db.delete(usuario)
    db.commit()
    return {"message": "Usuário e registros relacionados foram removidos com sucesso"}
